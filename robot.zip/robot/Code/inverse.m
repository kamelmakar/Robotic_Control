%{
This function is used to perform the inverse kinematics using the
inverseKinematics method which is a matlab built in function require the
tree model of our robot.
%}

function theta_2 =  inverse(z)

global robottree;

points = [ 0, 0, 0 ];
points(1,3) = z;

Initial_position = [0; 0];

qs = zeros(1, 2);
ik = inverseKinematics('RigidBodyTree', robottree);
weights = [0, 0, 0, 1, 1, 1];

    desired_position = trvec2tform(points);
    configSol = ik('end-effector',desired_position,weights,Initial_position);
    theta_2 = floor(rad2deg(configSol(2,1)));

end