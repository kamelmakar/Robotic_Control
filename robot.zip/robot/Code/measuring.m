%{
This function is used to measure the hights of our 3 positions using
ultrasonic sensor and apply the inverse kinematics using these hieghts
to get the value of theta_2 which is the angle requiered by the arm 
to reach the object.
%}

function [a , b , c] = measuring()   %% We have 3 outputs from this function which are the angels  for each position (a,b,c)

global motor_grip 
global motor_hand
global motor_base 
global pushButton_UP
global pushButton_Base
global Ultrasonic
global UP_Reading
global Base_Reading
global rotation_base
global rotation_up
global a
global b
global c

distance = readDistance(Ultrasonic);  %% get the distance between the end-effector and the object using the ultrasonic sensor at position A.
z = 0.21 - distance;  %% subtracting the distance from the actual ground to end-effector hight to get the actual hight of our object
a = inverse(z)  %% Calling our inverse function.


resetRotation(motor_base);
rotation_base = abs(readRotation(motor_base));
motor_base.Speed = -25;

while rotation_base <= 100*3  %% Rotate the robot to position B to apply the same procedure again. (we multiplied by 3 which is the gear ratio)
rotation_base = abs(readRotation(motor_base));
end
motor_base.Speed = 0;
pause(3);
distance = readDistance(Ultrasonic);
z = 0.21 - distance;
b = inverse(z)


rotation_base = abs(readRotation(motor_base)); 
motor_base.Speed = -25;

while rotation_base <= 190*3  %% Rotate the robot to position B to apply the same procedure again. 
rotation_base = abs(readRotation(motor_base));
end
motor_base.Speed = 0;
pause(3);

distance = readDistance(Ultrasonic);
z = 0.21 - distance;
c = inverse(z)


