%% Main Code

clear all;
close all;
clc;

global motor_grip;
global motor_hand;
global motor_base; 
global pushButton_UP;
global pushButton_Base;
global Ultrasonic;
global UP_Reading;
global Base_Reading;
global robottree;
global rotation_base;
global rotation_up;
global a;
global b;
global c;

robottree = rigidBodyTree('DataFormat','column','MaxNumBodies',5);   %% Defining our robot using Tree method which is a Matlab function used to simulate the robot into matlab by defining the Joint types and positions. 

L0 = 0.05; L1 = 0.05; L2 = 0.095; L3 = 0.185; L4 = 0.110; 

body = rigidBody('link0');     %% Defining our first joint as FIXED and its position at [0,0,0]
joint = rigidBodyJoint('joint0', 'fixed');
setFixedTransform(joint,trvec2tform([0 0 0]));
body.Joint = joint;
addBody(robottree, body, 'base');

body = rigidBody('link1');     %% Defining our Second joint as revolute and its position at [0,0,L0] from the previous joint
joint = rigidBodyJoint('joint1','revolute');
setFixedTransform(joint, trvec2tform([0,0,L0]));
joint.JointAxis = [0 0 1];
body.Joint = joint;
addBody(robottree, body, 'link0');

body = rigidBody('link2');
joint = rigidBodyJoint('joint2','fixed');
setFixedTransform(joint, trvec2tform([0,0,L1]));
body.Joint = joint;
addBody(robottree, body, 'link1');

body = rigidBody('link3');
joint = rigidBodyJoint('joint3','revolute');    
setFixedTransform(joint, trvec2tform([-L2*cosd(45), 0, L2*sind(45)]));
joint.JointAxis = [0 1 0];  
body.Joint = joint;
addBody(robottree, body, 'link2');

body = rigidBody('link4');
joint = rigidBodyJoint('joint4','fixed');
setFixedTransform(joint, trvec2tform([L3*cosd(30), 0, L3*sind(30)]));
body.Joint = joint;
addBody(robottree, body, 'link3');

body = rigidBody('end-effector');   %% Defining our end effector position at [0,0,-L4] from the previous joint
joint = rigidBodyJoint('joint5','fixed');
setFixedTransform(joint, trvec2tform([0, 0, -L4]));
body.Joint = joint;
addBody(robottree, body, 'link4');

Initial_position = [0;0];
show(robottree,Initial_position);

%% Declaration and Initialization

robot = legoev3('usb');
motor_grip = motor(robot,'A') ;            %% gripper motor
motor_hand = motor(robot,'B')  ;           %% up and down motor
motor_base = motor(robot,'C') ;            %% Base motor
pushButton_UP = touchSensor(robot,3)  ;    %% upper pushbutton
pushButton_Base = touchSensor(robot,1);    %% Base pushbutton
Ultrasonic = sonicSensor(robot,2)  ;       %% UltraSonic Sensor
UP_Reading = readTouch(pushButton_UP)  ;   %% Upper push button state
Base_Reading = readTouch(pushButton_Base); %% Lower push button state

resetRotation(motor_hand); %% Reset the encoders of the motors
resetRotation(motor_base);

rotation_base = abs(readRotation(motor_base)); 
rotation_up = abs(readRotation(motor_hand));

%% home position

motor_grip.Speed = 5;  %% close the grip
pause(1);
motor_grip.Speed = 0;

motor_grip.Speed = -5; %% open the grip
pause(0.5)
motor_grip.Speed = 0;

homeing();  %% Calling our homeing function.

[a , b , c] = measuring(); %% Calling our measuring function.




%% Tasks

homeing()

%%5
task = 5
picking('B');   %% Calling our picking function from position B.
placing('C');   %% Calling our placing function at position C.
homeing();      %% Calling our homeing function.

%%6
task = 6
picking('C');
placing('A');
homeing();

%%7
task = 7
picking('A');
placing('B');
homeing();

%%8
task = 8
picking('B');
placing('A');
homeing();

%%9
task = 9
picking('A');
placing('C');
homeing();

%%10
task = 10
picking('C');
placing('B');
homeing();
