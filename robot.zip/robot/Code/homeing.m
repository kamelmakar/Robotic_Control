%{
This function is used to move the motor to the home position
by moving the arm up until it touchs the upper touch sensor and rotating
the base until it touchs the lower touch sensor
%}

function homeing()

global motor_hand
global motor_base 
global pushButton_UP
global pushButton_Base
global Ultrasonic
global UP_Reading
global Base_Reading
global rotation_base

UP_Reading = readTouch(pushButton_UP);   %% moving our hand up to its home position
start(motor_hand);  
while UP_Reading ~= 1  %% hand home position
  motor_hand.Speed = -25;
  UP_Reading = readTouch(pushButton_UP); 
end

motor_hand.Speed = 0;
resetRotation(motor_hand);


Base_Reading = readTouch(pushButton_Base); %% rotating our base clockwise to its home position
start(motor_base);
while Base_Reading ~= 1 %% base home position
  motor_base.Speed = 25;
  Base_Reading = readTouch(pushButton_Base);
end

motor_base.Speed = 0;
resetRotation(motor_base);
rotation_base = 0;
pause(1);

end