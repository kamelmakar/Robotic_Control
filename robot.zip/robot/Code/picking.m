%{
This function is used to recieve the desired position and pick the ball
from it.
%}

function picking(position)

global motor_grip 
global motor_hand
global motor_base 
global pushButton_UP
global pushButton_Base
global Ultrasonic
global UP_Reading
global Base_Reading
global rotation_base
global rotation_up
global a
global b
global c

if position == 'A'  %% Assigning the angles values depending on the given position.
    theta_1 = 0;
    theta_2 = a;
end

if position == 'B'
    theta_1 = 300;
    theta_2 = b;
end

if position == 'C'
    theta_1 = 570;
    theta_2 = c;
end


difference = theta_1 - rotation_base;   % We calculate the difference between the new desired position and the current position 
                                        % to decide in which direction should we rotate
if difference > 0 
    speed = -25;
end

if difference < 0 
    speed = 25;
else 
    speed = -25;
end

    
    
resetRotation(motor_base);
rotation_base = abs(readRotation(motor_base));
motor_base.Speed = speed;

while rotation_base <= abs(difference) %% Rotate the base motor to the desired posstion.
rotation_base = abs(readRotation(motor_base));
end
rotation_base = theta_1;
motor_base.Speed = 0;
pause(1);



start(motor_hand);
resetRotation(motor_hand);   
rotation_up  = abs(readRotation(motor_hand));
motor_hand.Speed = 25;

while rotation_up <= (theta_2)*5 %%  move the robot hand to the desired position (we multiplied by 5 which is the gear ratio)
rotation_up = abs(readRotation(motor_hand));
end
motor_hand.Speed = 0;

motor_grip.Speed = 5;  %% close the grip
pause(1);
motor_grip.Speed = 0;

UP_Reading = readTouch(pushButton_UP);
Base_Reading = readTouch(pushButton_Base);

while UP_Reading ~= 1  %% hand home position
  motor_hand.Speed = -25;
  UP_Reading = readTouch(pushButton_UP); 
end
motor_hand.Speed = 0;
resetRotation(motor_hand);

end


